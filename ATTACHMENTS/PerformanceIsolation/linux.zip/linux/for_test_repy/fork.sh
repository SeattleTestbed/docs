#!/bin/bash
echo


for ((m = 0; m<2; m++)); do
 for i in 1; do
  python repy.py restrictionsnot.full fork1.repy &
 done
 for j in 2; do
  python repy.py restrictionsnot.full fork2.repy &
 done
 for k in 3; do
  python repy.py restrictionsnot.full fork3.repy &
 done
 for l in 4; do
  python repy.py restrictionsnot.full fork4.repy &
 done
 sleep 150
done

for ((n = 0; n<3; n++)); do
 for x in 1; do
  python repy.py restrictionsnot.full fork.repy &
 done
 for i in 1; do
  python repy.py restrictionsnot.full fork1.repy &
 done
 for j in 2; do
  python repy.py restrictionsnot.full fork2.repy &
 done
 for k in 3; do
  python repy.py restrictionsnot.full fork3.repy &
 done
 for l in 4; do
  python repy.py restrictionsnot.full fork4.repy &
 done
 sleep 150
 killall -9 Python python
done

python CalcAvg.py fork