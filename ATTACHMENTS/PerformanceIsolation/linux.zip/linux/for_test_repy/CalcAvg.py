import sys

def main(des):
        calcAvg(des)

def calcAvg(des):
	str1 = des + "1.txt"
	fileOne = open(str1, 'r')
	fileList=[];
	for line in fileOne:
                if line != "\n":
			fileList.append(line)        
	valueOne=fileList.pop()
	valueTwo=fileList.pop()
	valueThree=fileList.pop()
	valueFour=fileList.pop()
	valueFive=fileList.pop()
	averageOne=(float(valueFour) + float(valueFive))/2
	averageTwo=(float(valueOne) + float(valueTwo) + float(valueThree))/3
	percentDifference=((averageTwo/averageOne)*100)-100
	print "percent difference: " + str(percentDifference) + "%"
        fileOne = open(str1, 'a')
        fileOne.write("\n" + str(percentDifference) )
        fileOne.close()

	str2 = des + "2.txt"
	fileTwo = open(str2, 'r')
	fileList=[];
	for line in fileTwo:
                if line != "\n":
			fileList.append(line)        
	valueOne=fileList.pop()
	valueTwo=fileList.pop()
	valueThree=fileList.pop()
	valueFour=fileList.pop()
	valueFive=fileList.pop()
	averageOne=(float(valueFour) + float(valueFive))/2
	averageTwo=(float(valueOne) + float(valueTwo) + float(valueThree))/3
	percentDifference=((averageTwo/averageOne)*100)-100
	print "percent difference: " + str(percentDifference) + "%"
        fileTwo = open(str2, 'a')
        fileTwo.write("\n" + str(percentDifference) )
        fileTwo.close()
	
	str3 = des + "3.txt"
	fileThree = open(str3, 'r')
	fileList=[];
	for line in fileThree:
                if line != "\n":
			fileList.append(line)        
	valueOne=fileList.pop()
	valueTwo=fileList.pop()
	valueThree=fileList.pop()
	valueFour=fileList.pop()
	valueFive=fileList.pop()
	averageOne=(float(valueFour) + float(valueFive))/2
	averageTwo=(float(valueOne) + float(valueTwo) + float(valueThree))/3
	percentDifference=((averageTwo/averageOne)*100)-100
	print "percent difference: " + str(percentDifference) + "%"
        fileThree = open(str3, 'a')
        fileThree.write("\n" + str(percentDifference) )
        fileThree.close()

	str4 = des + "4.txt"
	fileFour = open(str4, 'r')
	fileList=[];
	for line in fileFour:
                if line != "\n":
			fileList.append(line)        
	valueOne=fileList.pop()
	valueTwo=fileList.pop()
	valueThree=fileList.pop()
	valueFour=fileList.pop()
	valueFive=fileList.pop()
	averageOne=(float(valueFour) + float(valueFive))/2
	averageTwo=(float(valueOne) + float(valueTwo) + float(valueThree))/3
	percentDifference=((averageTwo/averageOne)*100)-100
	print "percent difference: " + str(percentDifference) + "%"
        fileFour = open(str4, 'a')
        fileFour.write("\n" + str(percentDifference) )
        fileFour.close()

if __name__ == '__main__':
	main(sys.argv[1])
