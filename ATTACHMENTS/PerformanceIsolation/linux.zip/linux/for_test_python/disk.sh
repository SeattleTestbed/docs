#!/bin/bash
echo


for ((m = 0; m<2; m++)); do
 for c in 1; do
  python disk1.py &
 done
 for j in 2; do
  python disk2.py &
 done
 for k in 3; do
  python disk3.py &
 done
 for l in 4; do
  python disk4.py &
 done
 sleep 60
done


for ((n = 0; n<3; n++)); do
 for x in 1; do
  ./run_iozone.sh &
 done
 for c in 1; do
  python disk1.py &
 done
 for j in 2; do
  python disk2.py &
 done
 for k in 3; do
  python disk3.py &
 done
 for l in 4; do
  python disk4.py &
 done
 sleep 80
 killall -9 Python python
 killall -9 iozone
done

python CalcAvg.py disk
