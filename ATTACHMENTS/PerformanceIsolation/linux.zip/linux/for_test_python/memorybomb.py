import time
a = ["a"]
for i in range(0,100):
 try:
  a = a + a
  b = a
 except MemoryError:
  try:
   a = a + b
  except MemoryError:
   time.sleep(100)
