#!/bin/bash
echo


for ((m = 0; m<2; m++)); do
 for i in 1; do
  python fork1.py &
 done
 for j in 2; do
  python fork2.py &
 done
 for k in 3; do
  python fork3.py &
 done
 for l in 4; do
  python fork4.py &
 done
 sleep 150
done

for ((n = 0; m<3; m++)); do
 for x in 1; do
  python fork.py &
 done
 for i in 1; do
  python fork1.py &
 done
 for j in 2; do
  python fork2.py &
 done
 for k in 3; do
  python fork3.py &
 done
 for l in 4; do
  python fork4.py &
 done
 sleep 150
done

python CalcAvg.py fork
killall -9 Python python