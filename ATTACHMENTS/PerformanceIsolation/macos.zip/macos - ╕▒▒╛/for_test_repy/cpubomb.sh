#!/bin/bash
echo


for NO in {1..2}
do
 for i in 1
 do
  python repy.py restrictionsnot.full cpubomb1.repy &
 done
 for j in 2
 do
  python repy.py restrictionsnot.full cpubomb2.repy &
 done
 for k in 3
 do
  python repy.py restrictionsnot.full cpubomb3.repy &
 done
 for l in 4
 do
  python repy.py restrictionsnot.full cpubomb4.repy &
 done
 sleep 150
done

for STRESS in {1..3}
do
 for x in 1
 do
  python repy.py restrictionsnot.full cpubomb.repy &
 done
 for i in 1
 do
  python repy.py restrictionsnot.full cpubomb1.repy &
 done
 for j in 2
 do
  python repy.py restrictionsnot.full cpubomb2.repy &
 done
 for k in 3
 do
  python repy.py restrictionsnot.full cpubomb3.repy &
 done
 for l in 4
 do
  python repy.py restrictionsnot.full cpubomb4.repy &
 done
 sleep 150
 killall -9 Python python
done

python CalcAvg.py cpu