#!/bin/bash
echo


for NO in {1..2}
do
 for c in 1
 do
  python disk1.py &
 done
 for j in 2
 do
  python disk2.py &
 done
 for k in 3
 do
  python disk3.py &
 done
 for l in 4
 do
  python disk4.py &
 done
 sleep 60
done


for STRESS in {1..3}
do
 for x in 1
 do
  ./run_iozone.sh &
 done
 for c in 1
 do
  python disk1.py &
 done
 for j in 2
 do
  python disk2.py &
 done
 for k in 3
 do
  python disk3.py &
 done
 for l in 4
 do
  python disk4.py &
 done
 sleep 80
done

python CalcAvg.py disk
killall -9 Python python