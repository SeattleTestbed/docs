#!/bin/bash
echo


for NO in {1..2}
do
 for i in 1
 do
  python memorybomb1.py &
 done
 for j in 2
 do
  python memorybomb2.py &
 done
 for k in 3
 do
  python memorybomb3.py &
 done
 for l in 4
 do
  python memorybomb4.py &
 done
 sleep 60
done

for STRESS in {1..3}
do
 for x in 1
 do
  python memorybomb.py &
 done
 for i in 1
 do
  python memorybomb1.py &
 done
 for j in 2
 do
  python memorybomb2.py &
 done
 for k in 3
 do
  python memorybomb3.py &
 done
 for l in 4
 do
  python memorybomb4.py &
 done
 sleep 80
done

python CalcAvg.py memory
killall -9 Python python