import time

time.sleep(150)