import time
from time import clock
def getruntime():
 return clock()

def fib(n):
 if n<=1:
   return 1
 else:
   return fib(n-1) + fib(n-2)


start = getruntime()
throwaway = fib(37)
t= str(getruntime() - start)
print(t)
print("\n")
f=open("disk1_py.txt", 'a')
u= t + "\n"
f.write(u)
f.close()

