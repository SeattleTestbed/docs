"""
<Program Name>
  Huxiang Webhost Service

<Author>
  Alan Loh

<Date Started>
  January 15, 2011

<Description>
  Uploads and hosts a website on max number of nodes available to the user

  An all-in-one program a user can use to host a website under their SeattleGENI
  username. Hosting is done largely through the use of Overlord, which will
  ensure that the website stays up until manual termination of the process by 
  the user.

  More information on the process can be found in Overlord's documentation and
  Wiki page: https://seattle.cs.washington.edu/wiki/Libraries/Overlord

  The program requires the following arguments in this specific order:
  [single-word address] - The single-word that will be appended to the beginning 
    of ".zenodotus.cs.washington.edu", acting as the first part of the website's
    address
  [SeattleGENI username] - The SeattleGENI username that will be used to retrieve
    the vessels hosting the website
  [directory path of file folder] - The directory of the folder containing the
    files to be hosted
  [URL home path] - The path directing to the home page file within the webfiles
    folder. Will also affect default pathing of URLs

  The program will output a "huxiang_config" file that will overwrite any config
  file of the same name in the current directory. huxiang_config is written based
  on the user's passed arguments, and will determine the structure of the site 
  map of the website, as well as the zenodotus address the site will be hosted
  under.

<Requirements>
  Overlord setted up in the way specified by Overlord's Wiki page
  A copy of the user's public and privatekey within the same directory as
  huxiang_creatory.py
  huxiang_client.repy preprocessed into huxiang_server.repy, also within the same
  directory as huxiang_creator.py

  WEBSITE FILE REQUIREMENTS
  There are several conditions the web files need to follow in order for the web 
  server to work correctly
  - The home folder of the web files being uploaded must contain an "index.html"
    that will act as the homepage of the website
  - Links between pages hosted on the same server must have relative addresses
    instead of absolute URLs

After running, the user will need to check on the status of the hosting nodes
through seash itself in case the website isn't accessible. Keep in mind there
may be a period of delay from the start of the program's execution to the 
website actually being accessible.


"""
import sys
sys.path.append("./overlord")
sys.path.append("./overlord/experimentlibrary")
import experimentlib
import overlord
import repyhelper
repyhelper.translate_and_import("serialize.repy")


# Identity object of the SeattleGENI username passed
# Created through experimentlibrary's create_identity method
identity = None

# Used to assign ID to each file being uploaded
file_count = 0;

# A dictionary of the local files to be upload, with the file's directory
# as the key and the filename ID the file will be uploaded under as the value
files_to_upload = {'huxiang_server.repy':'huxiang_server.repy', 'huxiang_config':'huxiang_config'}

# Dictionary of vessels with their corresponding IP and name that failed
# during file upload
bad_vessels = {}





def main():
  global identity


  # Make sures there are four total arguments passed (including the filename of this program)
  if not len(sys.argv) == 5:
    print "Invalid arguments. Expected format: [single-word address] [SeattleGENI username] [directory path of file folder] [URL home path]"
    return
  # Assign sensible names to each variable
  else:
    address_word = sys.argv[1]
    geni_username = sys.argv[2]
    file_directory = sys.argv[3]
    home_path = sys.argv[4]


  # Checks to be sure there are no punctuations within the address word that may
  # result in an invalid zenodotus address
  symbols = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
  for char in symbols:
    if char in address_word:
      print "Invalid address: " + address_word + " needs to be a single word with no symbols or punctuation"
      return

  # Checks that the proper files are being passed for publickey and privatekey,
  # and the directories to said files are correct
  try:
    identity = experimentlib.create_identity_from_key_files(geni_username + '.publickey', geni_username + '.privatekey')
  except OSError:
    print "Key files not found in current directory. Make sure public and private key of username is located within same directory as huxiang_creator.py"
    return

    
  # Checks that the passed directoy path is correct
  if not os.path.isdir(file_directory):
    print "Invalid directory: " + file_directory + " does not exist or is an invalid directory path"
    return


  # Removes leading forward slashes and check that the file exists in the directory listed
  home_path.strip('/')
  if not os.path.isfile(file_directory.rstrip('/') + '/' + home_path):
    print "Invalid page file: " + file_directory.rstrip('/') + "/" + home_path + " does not exist"
    return


  # Find the port number assigned to the user's identity
  # Needed to write to configuration file
  port_number = experimentlib.seattlegeni_user_port(identity)


  # Build file dictionary and configuration file (includes address, port number, and file directory)
  build_file_dictionary(address_word, port_number, file_directory, home_path)



  # Calculate the number of vessels the identity is allowed to obtain at max
  max_vessels_allowed = experimentlib.seattlegeni_max_vessels_allowed(identity)

  # Initialize overlord
  overl = overlord.Overlord(geni_username, max_vessels_allowed, "wan", None)
  overl.init_vessels_func = init_vessels

  overl.logger.info("Home address will be: " + address_word + ".zenodotus.cs.washington.edu:" + str(port_number))

  overl.run()





def init_vessels(overlord, fresh_handlers, vessel_handlers):
  """
  <Purpose>
    Replaces Overlord's default behavior in vessel initialization. Uploads the
    web files and starts the huxiang server on each newly acquired vessels.
    Releases any vessels that failed during the process.

  <Arguments>
    overlord
      The current overlord instance being ran
    fresh_handlers
      The newly acquired vessels that have yet to be initialized
    vessel_handlers
      The list of vessels currently owned that have already been initialized

  <Exceptions>
    None

  <Side Effects>
    None

  <Returns>
    An updated list of vesselhandles including the newly initialized vessels
  """
  # Upload files to vessels
  successful_handlers = upload_web_files(overlord, fresh_handlers)

  # Start the server hosting
  return_handlers = overlord.run_on_vessels(successful_handlers, "huxiang_server.repy")

  # Release vessels the failed to run
  release_handlers = overlord.list_difference(successful_handlers, return_handlers)
  overlord.release_vessels(release_handlers)

  vessel_handlers.extend(return_handlers)

  return vessel_handlers





def build_file_dictionary(address, port, file_directory, home_path):
  """
  <Purpose>
    Builds the file_dictionary with all the files contained within the directory
    passed, assigning each file directory a filename ID. Serializes the
    completed dictionary and writes it to huxiang_config in addition to the
    passed address word and port number.

  <Arguments>
    address
      A single word string that will determine the website's zenodotus address

    port
      The SeattleGENI user's port number

    file_directory
      Directory of the folder containing the files to be uploaded

  <Exceptions>
    None

  <Side Effects>
    None

  <Returns>
    None
  """

  file_dictionary = _build_file_dictionary(file_directory)

  # Serialize the site map data into a string for file storage
  serialized_site_map = serialize_serializedata(file_dictionary)

  # Outputs the serialized site map as a text file. Will overwrite existing file
  config_file = open('huxiang_config', 'w')
  config_file.write(address + "\n")
  config_file.write(home_path + "\n")
  config_file.write(str(port) + "\n")
  config_file.write(serialized_site_map)
  config_file.close()




# Recursive method that assigns a file ID to each file being uploaded
def _build_file_dictionary(directory):
  global file_count

  # Temporary dictionary that gets returned with each recursion
  sub_dictionary = {}

  # Returns full pathname of given directory.
  # If empty, returns full path of current directory
  abs_pathname = os.path.abspath(directory)

  for filename in os.listdir(abs_pathname):
    if os.path.isfile(os.path.join(abs_pathname,filename)):
      # Assigns an ID to the file for the purpose of uploading to a set pattern of filenames
      file_id = "file" + str(file_count)
      sub_dictionary[filename] = file_id

      # Add the directory path of the file to the list of directories to be uploaded
      files_to_upload[os.path.join(directory,filename)] = file_id
      file_count += 1

    # In the case of a folder name, recurses and assigns the returned dictionary 
    # as the folder name's value
    else:
      sub_dictionary[filename] = _build_file_dictionary(os.path.join(directory,filename))

  # Add an entry for each sub dictionary to ensure that the location query can 
  # be called from any webpage within any directory
  sub_dictionary["node_location.html"] = "node_location.html"

  return sub_dictionary




def upload_web_files(overlord, fresh_handlers):
  """
  <Purpose>
    Uploads the web files contained within the directory passed. 
    Any vessels that failed to complete an upload will be released.

  <Arguments>
    overlord
      The current overlord instance being ran
    fresh_handlers
      The list of newly acquired vessels being initialized

  <Exceptions>
    None

  <Side Effects>
    Upload process is parallelized
    Will log an error message if an upload fails

  <Returns>
    A list of vesselhandlers of the vessels that successfully uploaded all the 
    files
  """
  global bad_vessels

  # Clear bad_vessels of values pertaining to the last run
  bad_vessels = {}

  overlord.logger.info("Uploading files")

  experimentlib.run_parallelized(fresh_handlers, _upload_web_files_helper, overlord)

  # Release any vessels that failed during the upload process and update the
  # vesselhandle_list
  overlord.logger.info("Releasing " + str(len(bad_vessels.keys())) + 
                       " vessels because of failure during upload")
  overlord.release_vessels(bad_vessels.keys())
  fresh_handlers = overlord.list_difference(fresh_handlers, bad_vessels.keys())

  return fresh_handlers



# Helper function that's part of the parallelization of uploading files to vessels
def _upload_web_files_helper(vesselhandle, overlord):
  try:
    nodeid, vesselname = experimentlib.get_nodeid_and_vesselname(vesselhandle)
    nodelocation = experimentlib.get_node_location(nodeid)
    
    for local_filename in files_to_upload.keys():
      experimentlib.upload_file_to_vessel(vesselhandle, identity, local_filename, files_to_upload[local_filename])

    # Upload the config file and the actual repy client that will handle the HTTP requests
    experimentlib.upload_file_to_vessel(vesselhandle, identity, "huxiang_config")
    experimentlib.upload_file_to_vessel(vesselhandle, identity, "huxiang_server.repy")
      
  except experimentlib.NodeCommunicationError, e:
    overlord.logger.info("Failed to upload " + local_filename + " to vessel " + nodelocation + " " + vesselname + ". Error was: " + str(e))
    # Append the vessel's information to bad_vessels to keep track of nodes that
    # aren't hosting correctly
    bad_vessels[vesselhandle] = nodelocation + ":" + vesselname



if __name__ == "__main__":
  main()

