

import sys
import traceback



import repyhelper
repyhelper.translate_and_import('geoip_client.repy')
repyhelper.translate_and_import('experimentlib.py')
repyhelper.translate_and_import('httpserver.repy')
repyhelper.translate_and_import('httpretrieve.repy')



def lookup_avlbl_locations():

  identity = create_identity_from_key_files(SEATTLEGENI_PUBLICKEY_FILENAME, SEATTLEGENI_PRIVATE_FILENAME)

  nodelocation_list = lookup_node_locations_by_identity(identity)
  print("Number of advertising nodes: " + str(len(nodelocation_list)))

  vesselhandle_list = find_vessels_on_nodes(identity, nodelocation_list)  

  successful_running_proxy = []
  for vesselhandle in vesselhandle_list:
    try:
      # refresh vessel
      reset_vessel(vesselhandle, identity)
        
      nodeid, vesselname = get_nodeid_and_vesselname(vesselhandle)
      nodelocation = get_node_location(nodeid)

      # upload file  
      upload_file_to_vessel(vesselhandle, identity, 'proxypp.py')
      print("Uploaded proxy to " + nodelocation + " vessel " + vesselname)
          
      start_vessel(vesselhandle, identity, 'proxypp.py', [SEATTLEGENI_PORT])
      print("proxy started on " + nodelocation + " vessel " + vesselname)
      
      vessel_log = get_vessel_log(vesselhandle, identity)

      if 'Proxy running on' in vessel_log:
        # Successfully running proxy's
        (host, port) = get_host_and_port(nodelocation)
        successful_running_proxy.append(host)

      print vessel_log + ' at nodelocation '  + str(nodelocation)
      
    except SeattleExperimentError, e:
      print 'failed ' + str(e)
      pass

  
  # convert the successful proxy ip addresses to a location     
  locations_str = ''
  for host in successful_running_proxy: 
    geoip_init_client('http://geoip.cs.washington.edu:12679')
    ip_info = geoip_record_by_addr(host)
    location = ip_info['city'] + ' ' + ip_info['region_name'] + ', ' + ip_info['country_code']
    locations_str += location + ' : '
    host_location_log[location] = host + ':' + str(SEATTLEGENI_PORT)

  return locations_str




def lookup_vesselstat():
  identity = create_identity_from_key_files(SEATTLEGENI_PUBLICKEY_FILENAME, SEATTLEGENI_PRIVATE_FILENAME)

  nodelocation_list = lookup_node_locations_by_identity(identity)
  print("Number of advertising nodes: " + str(len(nodelocation_list)))

  vesselhandle_list = find_vessels_on_nodes(identity, nodelocation_list)
  
  used = {}
  
  overall = ''
  for vesselhandle in vesselhandle_list:
    vessel_log = get_vessel_log(vesselhandle, identity)
    overall += vessel_log
    print vessel_log  
  return overall




def viewpoints_directrory(httprequest_dictionary):
  requested_path = httprequest_dictionary['path']
  http_query = httprequest_dictionary['querydict']
 
  if requested_path == '/' or requested_path == '':
    filelikeobj = open('mainviewpoints.html', mode='r')
    mainviewpoints = filelikeobj.read()
    return {'version':  '1.0', 'statuscode': 200, 'headers': {}, 'message': mainviewpoints, 'statusmsg':''}
    
  
  elif requested_path == '/location_lookup':
    locations = lookup_avlbl_locations()
    return {'version':  '1.0', 'statuscode': 200, 'headers': {}, 'message': locations, 'statusmsg':''}


  elif requested_path == '/lookup_stat':
    locations = lookup_vesselstat()
    return {'version':  '1.0', 'statuscode': 200, 'headers': {}, 'message': locations, 'statusmsg':''}

    
    
  elif requested_path == '/viewpoint_generator':
    #print httprequest_dictionary
    # get viewpoints url and locations from the received query
    viewpoints_url = http_query['viewpoints_url']
    viewpoints_location = http_query['viewpoints_location']
    # convert this location to ip and port using previous
    # (ip,port)= prev_log[viewpoints_location]

    #save the viewpoints location and url- if there is more requestes from browser
    viewpoints_log['viewpoints_url'] = viewpoints_url  
    viewpoints_log['viewpoints_location'] = viewpoints_location
    viewpoints_host_port = host_location_log[viewpoints_location] 
    (host, port)= viewpoints_host_port.split(':')
    
    print 'retrieve data at ' + viewpoints_url + ' at location ' + viewpoints_host_port
    
    try:
      retrieved_data = httpretrieve_get_string(viewpoints_url, None, None, None, [host, int(port)], 300)
    except Exception, e:
      print 'http retrieve failed ' + str(e)
      raise
    
    print 'retrieved_data \n' + retrieved_data
    return {'version':  '1.0', 'statuscode': 200, 'headers': {}, 'message': retrieved_data, 'statusmsg':''}

  

  else:
    # catch any other requests and redirect it to the viewpoints server at the viewpoints location
    #print httprequest_dictionary
    viewpoints_host = urlparse_urlsplit(viewpoints_log['viewpoints_url'])
    viewpoints_url = 'http://' + viewpoints_host['hostname'] + httprequest_dictionary['path'] 
    viewpoints_location = viewpoints_log['viewpoints_location']
    
    http_query = {'viewpoints_url': viewpoints_url, 'viewpoints_location': viewpoints_location}

    print 'redirect too http://127.0.0.1:12345/viewpoint_generator?' + urllib_quote_parameters(http_query)
    redirect_loc = 'http://127.0.0.1:12345/viewpoint_generator?' + urllib_quote_parameters(http_query)

    return {'version':  '1.0', 'statuscode': 301, 'headers': {'Location':redirect_loc}, 'message': '', 'statusmsg':''}


    
    

if __name__ == "__main__":
  # used to store requested data
  host_location_log = {}
  viewpoints_log = {}

  if len(sys.argv) != 3:
    raise Exception("ArgumentError: arguments have to be 3 you have " + str(len(sys.argv)))
  else:
    seattlegeni_username = sys.argv[1] 
    SEATTLEGENI_PUBLICKEY_FILENAME = seattlegeni_username + '.publickey' 
    SEATTLEGENI_PRIVATE_FILENAME =  seattlegeni_username + '.privatekey'
    SEATTLEGENI_PORT = sys.argv[2]


  
  try:     
    handle = httpserver_registercallback(('127.0.0.1',12345), viewpoints_directrory)
  except Exception, e:
    raise Exception('Server failed internally ' + str(e))  
  else: 
    print 'waiting...' 



